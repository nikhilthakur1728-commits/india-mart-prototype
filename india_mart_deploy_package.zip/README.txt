INDIA MART PROTOTYPE — DEPLOYMENT NOTES

Files:
- index.html: static marketplace prototype

Quick free preview:
1. Open GitHub and create a new repository, e.g. india-mart-prototype.
2. Upload index.html to the repository root.
3. Open repository Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select the main branch and /(root), then Save.
6. Wait for publishing and open the URL shown under Settings > Pages.

Important limitations:
- This is a front-end prototype. Product/cart/order data is stored in each visitor's own browser and is not shared between users.
- Google sign-in and phone OTP buttons are placeholders.
- Demo checkout does not collect payment or create real orders.
- The owner panel is not secure authentication; never use the demo code on a live site.
- GitHub Pages is suitable for a public static demo, not for a production marketplace with private admin tools or payments.

Next production steps:
1. Set up Firebase Authentication (Google + phone OTP).
2. Use Firestore or another database for shared products, users, carts and orders.
3. Enforce owner/seller roles with backend security rules/server-side checks.
4. Add secure image uploads, moderation, order management and payment gateway.
5. Configure shipping/delivery tracking, policies, privacy notice and customer support.
6. Test everything before accepting real orders or money.

Hosting reference:
https://firebase.google.com/docs/hosting/quickstart
GitHub Pages reference:
https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
